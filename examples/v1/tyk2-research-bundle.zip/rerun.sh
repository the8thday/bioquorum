#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
"${PYTHON:-python3}" run.py --verify-only
if [ "${1:-}" = "--verify-only" ]; then
    exit 0
fi
if [ -f env/pixi.lock ]; then
    exec pixi run --locked --manifest-path env/pixi.toml python "$PWD/run.py"
fi
exec "${PYTHON:-python3}" run.py
