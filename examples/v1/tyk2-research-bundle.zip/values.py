
def __bq_install():
    import math, re
    from IPython.display import publish_display_data

    name_ok = re.compile('[A-Za-z][A-Za-z0-9_]{0,63}').fullmatch

    class BioQuorum:
        """BioQuorum helpers available in every kernel."""

        def value(self, name, value, unit=None, desc=None):
            """Declare a named scalar result. Answers cite it as {{name}}.

            value: int, float or short str (numpy scalars are converted). unit: e.g. "genes".
            desc: what the number is, in one sentence. Returns value unchanged."""
            if not isinstance(name, str) or not name_ok(name):
                raise ValueError(
                    "bq.value name must start with a letter and use only letters, digits "
                    "and underscores (max 64): %r" % (name,)
                )
            v = value
            item = getattr(v, "item", None)
            if callable(item) and getattr(v, "shape", None) == ():
                v = item()
            if isinstance(v, bool) or not isinstance(v, (int, float, str)):
                raise TypeError(
                    "bq.value takes an int, float or str, got %s; declare one number per "
                    "name (tables and figures are cited as artifacts)" % type(value).__name__
                )
            if isinstance(v, float) and not math.isfinite(v):
                raise ValueError("bq.value: %s is not finite" % name)
            if isinstance(v, str) and len(v) > 200:
                raise ValueError("bq.value: text values are limited to 200 characters")
            if unit is not None and (not isinstance(unit, str) or len(unit) > 40):
                raise ValueError("bq.value: unit must be a short string")
            if desc is not None and (not isinstance(desc, str) or len(desc) > 500):
                raise ValueError("bq.value: desc must be a string of at most 500 characters")
            if isinstance(v, int):
                v = int(v)  # plain int, not a subclass
            shown = repr(v) if isinstance(v, str) else str(v)
            text = "bq.value %s = %s%s" % (name, shown, " " + unit if unit else "")
            payload = {"name": name, "value": v, "unit": unit, "desc": desc}
            publish_display_data({'application/vnd.bioquorum.value+json': payload, "text/plain": text})
            return value

        def figure_points(self, path, sample_ids, x, y):
            """Write normalized image coordinates (origin top left) alongside a figure."""
            import csv
            import math
            rows = list(zip(sample_ids, x, y, strict=True))
            seen = set()
            for sample, px, py in rows:
                if (
                    not isinstance(sample, str)
                    or not 0 < len(sample) <= 128
                    or sample in seen
                    or isinstance(px, bool)
                    or isinstance(py, bool)
                    or not isinstance(px, (int, float))
                    or not isinstance(py, (int, float))
                    or not (math.isfinite(px) and math.isfinite(py) and 0 <= px <= 1 and 0 <= py <= 1)
                ):
                    raise ValueError("Expected unique sample IDs and normalized coordinates")
                seen.add(sample)
            with open(str(path) + ".points.tsv", "w", encoding="utf-8", newline="") as stream:
                writer = csv.writer(stream, delimiter="\t")
                writer.writerow(["sample_id", "x", "y"])
                writer.writerows(rows)

        def __repr__(self):
            return "<bq: bq.value(name, value, unit=None, desc=None)>"

    return BioQuorum()


bq = __bq_install()
del __bq_install
__import__("sys").modules["bq"] = bq  # so a stray ``import bq`` returns the same object
