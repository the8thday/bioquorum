# BioQuorum research bundle

Use `sh rerun.sh --verify-only` to check file integrity. `Methods.md` contains an editable draft generated from the research record.

See review/limitations.json for incomplete evidence or review.
Review the archived code before running it. For trusted public bundles, run `sh rerun.sh`. The locked route requires pixi; the unlocked route requires a Python interpreter with jupyter_client and ipykernel. Set `PYTHON` to select it. The comparison reports environment identity separately.

Share with authorized recipients.
