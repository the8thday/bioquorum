# Methods draft

BioQuorum generated this draft from the archived research record. Review the source selection, scientific protocol and interpretation before publication.

## Evidence collection

Archived tool results and literature excerpts are in `review/sources.json`.

- <code>read_file</code>, call <code>01M80JYEHPZTFRAYFYGSKRDJ57</code>.

## Computational methods

### Run <code>01M80JYEHWC5VYVJ1W40VHX7W0</code>

The archived <code>python</code> code is in <code>runs/01M80JYEHWC5VYVJ1W40VHX7W0/code.py</code>. Code SHA-256 is <code>df05d4067d6ba7ae56abe41df7b89e1b8ada9aad7f81e13a253f4a90d097a947</code>.

Runtime fingerprint is <code>73eb648491be3bf9b5b26023981ec05c823d488c5526460530bc8812b050c4d6</code> and kernel isolation is <code>seatbelt</code>.

Recorded inputs and SHA-256 hashes

- <code>pso1.csv</code> · <code>c3deeb8883cbb21ac72006af242f1731aec0f752cb7dedb4f4cb8238b1fb66e7</code>

Named run outputs

- <code>pasi_gap</code> = <code>45.7</code> <code>percentage points</code>

### Run <code>01M80K531BDNH6RHHF0DYT4K2E</code>

The archived <code>python</code> code is in <code>runs/01M80K531BDNH6RHHF0DYT4K2E/code.py</code>. Code SHA-256 is <code>df05d4067d6ba7ae56abe41df7b89e1b8ada9aad7f81e13a253f4a90d097a947</code>.

Runtime fingerprint is <code>73eb648491be3bf9b5b26023981ec05c823d488c5526460530bc8812b050c4d6</code> and kernel isolation is <code>seatbelt</code>.

Recorded inputs and SHA-256 hashes

- <code>pso1.csv</code> · <code>c3deeb8883cbb21ac72006af242f1731aec0f752cb7dedb4f4cb8238b1fb66e7</code>

Named run outputs

- <code>pasi_gap</code> = <code>45.7</code> <code>percentage points</code>
